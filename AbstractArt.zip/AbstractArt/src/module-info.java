module AbstractArt {
}