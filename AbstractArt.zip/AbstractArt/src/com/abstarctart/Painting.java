package com.abstarctart;

public class Painting extends Art {
	String paintType;
	
	public Painting(String paintType) {
		super();
		this.paintType=paintType;
	}

	@Override
	void viewArt() {
		System.out.print("AA");
		
	}

}
