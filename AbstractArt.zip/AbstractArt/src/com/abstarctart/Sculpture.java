package com.abstarctart;

public class Sculpture extends Art {
	String material;
	
	public Sculpture(String material) {
		super();
		this.material=material;
	}

	@Override
	void viewArt() {
		System.out.println("AA");
		
		
	}

}
