package com.abstarctart;

public class Museum {

	public static void main(String[] args) {
		Painting paint1 = new Painting("Impressionism");
		Painting paint2 = new Painting ("Acrylic");
		Painting paint3 = new Painting ("Oil Painting");
		
		Sculpture sculpture1 = new Sculpture("Marble");
		Sculpture sculpture2 = new Sculpture ("Bronze");
		
		paint1.viewArt();
		paint2.viewArt();
		paint3.viewArt();
		
		sculpture1.viewArt();
		sculpture2.viewArt();

	}

}
